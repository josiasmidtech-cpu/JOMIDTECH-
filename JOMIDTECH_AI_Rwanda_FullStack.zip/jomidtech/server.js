const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-me-before-deployment';
const WHATSAPP = (process.env.WHATSAPP_NUMBER || '250737672032').replace(/\D/g, '');
const dbDir = path.join(__dirname, 'data');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(path.join(dbDir, 'jomidtech.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY, title TEXT NOT NULL, author TEXT NOT NULL, description TEXT NOT NULL, price_rwf INTEGER NOT NULL, category TEXT NOT NULL DEFAULT 'Health & Technology', cover TEXT DEFAULT '', download_url TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, book_id INTEGER, service TEXT, amount_rwf INTEGER NOT NULL, payment_method TEXT NOT NULL DEFAULT 'Airtel Money', payment_reference TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(book_id) REFERENCES books(id));
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, service TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const bookCount = db.prepare('SELECT COUNT(*) AS n FROM books').get().n;
if (!bookCount) {
  const insert = db.prepare('INSERT INTO books (title, author, description, price_rwf, category, cover) VALUES (?, ?, ?, ?, ?, ?)');
  insert.run('The Evolution of Medicine', 'N. Josias', 'Explore how medical knowledge, healthcare technologies, and clinical practice have evolved through history.', 5000, 'Medicine', '');
  insert.run('AI in Nursing and Midwifery', 'JOMIDTECH AI Rwanda', 'A beginner-friendly guide to artificial intelligence, digital health, and responsible use in care.', 4000, 'Health Technology', '');
  insert.run('Digital Skills for Students', 'JOMIDTECH AI Rwanda', 'Practical foundations for using digital tools to learn, create, and work online.', 3000, 'Digital Skills', '');
}
const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || '';
if (adminEmail && adminPassword && !db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail)) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')").run('Administrator', adminEmail, hash);
}

app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:', 'https:'], scriptSrc: ["'self'"], connectSrc: ["'self'"] } } }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 150, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, message: { error: 'Too many attempts. Try again later.' } });
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Please sign in first.' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); } catch { return res.status(401).json({ error: 'Session expired. Please sign in again.' }); }
}
function adminOnly(req, res, next) { if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Administrator access required.' }); next(); }
const safeUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role });

app.get('/api/config', (req, res) => res.json({ brand: 'JOMIDTECH AI RWANDA', whatsapp: WHATSAPP, paymentMethods: ['Airtel Money (manual confirmation)'] }));
app.get('/api/books', (req, res) => res.json(db.prepare('SELECT id,title,author,description,price_rwf,category,cover FROM books WHERE active=1 ORDER BY id DESC').all()));
app.post('/api/register', authLimiter, (req, res) => {
  const name = String(req.body.name || '').trim(); const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Enter your name (2–80 characters).' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Password must contain 10–128 characters.' });
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({ error: 'An account with this email already exists.' });
  const hash = bcrypt.hashSync(password, 12); const result = db.prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)').run(name,email,hash);
  const user = db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(result.lastInsertRowid);
  const token = jwt.sign(safeUser(user), JWT_SECRET, { expiresIn: '7d' }); res.status(201).json({ token, user: safeUser(user) });
});
app.post('/api/login', authLimiter, (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Email or password is incorrect.' });
  const token = jwt.sign(safeUser(user), JWT_SECRET, { expiresIn: '7d' }); res.json({ token, user: safeUser(user) });
});
app.get('/api/me', auth, (req,res) => { const user = db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(req.user.id); if (!user) return res.status(404).json({error:'Account not found.'}); res.json({user}); });
app.post('/api/orders', auth, (req,res) => {
  const bookId = req.body.bookId ? Number(req.body.bookId) : null; const service = String(req.body.service || '').trim().slice(0,120);
  const reference = String(req.body.paymentReference || '').trim().slice(0,100);
  let amount = Number(req.body.amountRwf);
  if (bookId) { const book = db.prepare('SELECT id,price_rwf FROM books WHERE id=? AND active=1').get(bookId); if (!book) return res.status(404).json({error:'Book not found.'}); amount = book.price_rwf; }
  if (!Number.isInteger(amount) || amount < 500 || amount > 10000000) return res.status(400).json({error:'Invalid order amount.'});
  if (!bookId && service.length < 2) return res.status(400).json({error:'Choose a book or enter a service.'});
  const result = db.prepare('INSERT INTO orders (user_id,book_id,service,amount_rwf,payment_reference) VALUES (?,?,?,?,?)').run(req.user.id,bookId,service,amount,reference);
  res.status(201).json({message:'Order received. It remains pending until payment is checked by the administrator.',orderId:result.lastInsertRowid});
});
app.get('/api/orders', auth, (req,res) => {
  const rows = req.user.role === 'admin' ? db.prepare(`SELECT o.*,u.name customer_name,u.email,b.title book_title FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN books b ON b.id=o.book_id ORDER BY o.id DESC LIMIT 200`).all() : db.prepare(`SELECT o.*,b.title book_title FROM orders o LEFT JOIN books b ON b.id=o.book_id WHERE o.user_id=? ORDER BY o.id DESC`).all(req.user.id);
  res.json(rows);
});
app.patch('/api/orders/:id/status', auth, adminOnly, (req,res) => { const status = String(req.body.status || ''); if (!['pending','paid','fulfilled','cancelled'].includes(status)) return res.status(400).json({error:'Invalid status.'}); const r = db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,Number(req.params.id)); if (!r.changes) return res.status(404).json({error:'Order not found.'}); res.json({message:'Order updated.'}); });
app.post('/api/contact', (req,res) => {
  const name = String(req.body.name || '').trim().slice(0,80); const email = String(req.body.email || '').trim().slice(0,120); const service = String(req.body.service || '').trim().slice(0,120); const message = String(req.body.message || '').trim().slice(0,2000);
  if (name.length < 2 || !email.includes('@') || service.length < 2 || message.length < 5) return res.status(400).json({error:'Please complete all fields with valid information.'});
  db.prepare('INSERT INTO messages (name,email,service,message) VALUES (?,?,?,?)').run(name,email,service,message); res.status(201).json({message:'Thank you. Your request has been saved.'});
});
app.get('/api/admin/messages', auth, adminOnly, (req,res) => res.json(db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 200').all()));
app.post('/api/admin/books', auth, adminOnly, (req,res) => { const {title,author,description,priceRwf,category,cover,downloadUrl} = req.body; if (!String(title||'').trim() || !String(author||'').trim() || !String(description||'').trim() || !Number.isInteger(Number(priceRwf)) || Number(priceRwf)<0) return res.status(400).json({error:'Title, author, description and valid price are required.'}); const r=db.prepare('INSERT INTO books (title,author,description,price_rwf,category,cover,download_url) VALUES (?,?,?,?,?,?,?)').run(String(title).slice(0,160),String(author).slice(0,120),String(description).slice(0,2000),Number(priceRwf),String(category||'General').slice(0,80),String(cover||'').slice(0,500),String(downloadUrl||'').slice(0,1000)); res.status(201).json({id:r.lastInsertRowid}); });
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => console.log(`JOMIDTECH AI RWANDA running at http://localhost:${PORT}`));
