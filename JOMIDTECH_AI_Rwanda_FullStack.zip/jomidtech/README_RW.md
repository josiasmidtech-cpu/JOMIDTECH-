# JOMIDTECH AI RWANDA — Full-stack starter

Uyu mushinga ufite **frontend** (urubuga abakiriya babona) na **backend** (API, konti, ibitabo, orders, na database). Ni starter project; ntabwo iraba online kandi ntabwo irimo kwishyuza Airtel Money mu buryo bwikora.

## Ibirimo
- Responsive landing page: services, e-books, contact form, WhatsApp.
- Customer registration/login; passwords zibikwa nka bcrypt hashes.
- SQLite database: users, books, orders, contact messages.
- Customer ashobora kureba orders ze.
- Admin API ifite role check yo kureba orders/messages, guhindura order status, no kongeramo ebook.
- Rate limiting, Helmet security headers, input validation.
- Airtel Money igaragazwa nka manual payment gusa. Nyuma hakenewe integration yemewe na provider kugira ngo payment ibe automatic.

## Ibisabwa
- Node.js 20 cyangwa hejuru.
- npm.

## Gutangiza kuri computer
1. Extract/unzip iyi folder.
2. Fungura terminal muri folder.
3. Koresha `npm install`.
4. Kora kopi ya `.env.example` uyite `.env`.
5. Hindura `JWT_SECRET`, `ADMIN_EMAIL`, na `ADMIN_PASSWORD` ukoresheje secret ikomeye. Ntugashyire `.env` kuri GitHub cyangwa ngo wohereze password ku bandi.
6. Koresha `npm start`.
7. Fungura `http://localhost:3000` muri browser.

## Admin account
Admin account ikorwa ku ntangiriro niba `ADMIN_EMAIL` na `ADMIN_PASSWORD` byashyizwe muri `.env`. Koresha password nshya kandi ikomeye. Niba database yarakozwe mbere, guhindura `.env` ntibihindura password ya admin yari isanzwe muri database.

## API endpoints
- `GET /api/books` — public book catalogue.
- `POST /api/register`, `POST /api/login`, `GET /api/me` — customer accounts.
- `POST /api/orders`, `GET /api/orders` — orders.
- `POST /api/contact` — contact enquiry.
- `GET /api/admin/messages` — admin only.
- `POST /api/admin/books` — admin only, add book.
- `PATCH /api/orders/:id/status` — admin only, update order status.

Koresha `Authorization: Bearer <token>` kuri endpoints zisaba login. API iracyakeneye deployment configuration, backups, testing, privacy policy/terms, and production review before accepting real customers.

## Ibyo utagomba kwibagirwa
- Website **ntiratangazwa online** n'iyi ZIP yonyine.
- E-book download links n'ibiciro by'icyitegererezo bigomba gusimbuzwa ibyawe.
- Payment processing ntabwo ikora automatically. Ntusabe cyangwa ngo ubike Airtel Money PIN/OTP.
- Admin API ikoresha JWT; ku production shyiraho JWT_SECRET ikomeye, HTTPS, database backups, monitoring, no security review.
